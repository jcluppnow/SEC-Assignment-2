CALCULATOR API AND PLUGIN LOADING
Author: Jason Luppnow
Student ID: 18818835
Last Modified: 24/10/2020

INITIAL NOTES:
	Results from CPluginControl and WriteResultsPlugin will be generated in the java app directory.

HOW TO RUN THE PROGRAM:
	1. Navigate to Assignment Folder.
	2. In terminal run './gradlew -q run --console=plain'
		--console=plain cleans up outputing to CLI with Gradle.
		q is optional depending whether you want to use quiet mode which only shows errors.
	3. Follow menu prompts.

PLUGIN NOTES:
	All plugins are in the same package - 'org.plugins' except for CPluginControl which is in the 'org.cplugin' 
	package.

	Plugins currently existing are.
		1. CPluginControl.java - Inside the c_plugin_java/c_library subproject. Writes results to csv using Java & C++.
		2. NewFunctionsPlugin.java - Inside the new_functions_plugin subproject. Adds Fibonacci/Factorial functions.
		3. ProgressPlugin - Inside the progress_plugin subproject. Tracks the progress of the calculation.
			- If the difference between min/max are small you might not see the progress displayed on the screen.
			  If you scroll up all the print statements should be there.
		4. WriteResultsPlugin - Inside the write_results_plugin subproject. Writes results to csv using Apache Commons.

API NOTES:
	
	All api classes are located in the org.calculator_api package.

	REQUIREMENTS FOR ALL PLUGINS.
		1. Any plugin must import the CalculatorPlugin interface.
			Using 'import org.calculator_api.CalculatorPlugin;'
		
		2. Then override the start method.
			@Override
			public void start()
			{
			    //Any code that is required the plugin to start
			    //belongs here.
			}


	ADD NEW FUNCTIONS:
		1. Import the Calculator Function Annotation from the api package 
			Using 'import org.calculator_api.CalculatorFunction;'

		2. Add the Calculator Function Annotation to your static method.
		 	Example:
				@CalculatorFunction
				public static int square(int x)
				{
					...;
				}

	REGISTER OBSERVERS
		1. We have 3 observers we can implement.
			InputValuesObserver - Need to override recieveValuesCallBack(...)
			ProgressObserver - Need to override notifyProgressCallback(...)
			ResultObserver - Need to override recieveResultsCallback(...)

		2. Inside your start methods depending on what interfaces you observe, you want to add themselves
		   to the Calculator Event Source Observers.

					
		
