/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ProgressPlugin.java                                           *
* Purpose:          Displays progress of calculation with a loading bar.          *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     14/10/2020                                                    *
**********************************************************************************/

//Define package for ProgressPlugin, this is a shared package for all plugins.
package org.plugins;

//Import Java Packages
import java.lang.Math.*;

//Import Custom Packages
import org.calculator_api.CalculatorEventSource;
import org.calculator_api.InputValuesObserver;
import org.calculator_api.CalculatorPlugin;
import org.calculator_api.ProgressObserver;

/**********************************************************************************
* Public Class:    ProgressPlugin                                                 *
* Extends:         None     			     	    		    			      *
* Implements:      CalculatorPlugin, InputValuesObserver, ProgressObserver        *
* Assertion:       Tracks input values and changing x value to display progress.  *
**********************************************************************************/
public class ProgressPlugin implements CalculatorPlugin, InputValuesObserver, ProgressObserver
{
	/**********************************
	*           Classfields           *
	**********************************/
	private CalculatorEventSource api;
	private String equation;
	private double min, max, increment;
	
	/******************************************************************************
	* Submodule: start                                                            *
	* Import:    inApi (CalculatorEventSource)									  *
	* Export:    None                                                             *
	* Assertion: Registers plugin with API.						    	          *
	******************************************************************************/	
	@Override
	public void start(CalculatorEventSource inApi)
	{
		//Set the classfields.
		api = inApi;
		
		//Register the Plugin as an InputValuesObserver & ProgressObserver.
		api.addInputValuesObserver(this);
		api.addProgressObserver(this);
	}
	
	/******************************************************************************
	* Submodule: recieveValuesCallBack                                            *
	* Import:    equation (String), min (Double), max (Double), increment         *
	*		     (Double)						                                  *
	* Export:    None                                                             *
	* Assertion: Recieves expression data and uses it to set classfields.    	  *
	******************************************************************************/
	@Override
	public void recieveValuesCallBack(String equation, double min, double max, double increment)
	{
		//Update the classfields with imports.
		this.equation = equation;
		this.min = min;
		this.max = max;
		this.increment = increment;
	}

	/******************************************************************************
	* Submodule: notifyProgressCallback                                           *
	* Import:    currentX (Double)												  *
	* Export:    None                                                             *
	* Assertion: Recieves currentX value and display the new progress.            *
	******************************************************************************/
	@Override
	public void notifyProgressCallback(double currentX)
	{
		//Calculate the percentage.
		int percentage = calculateProgressPercentage(currentX);

		//Print the progress on a new line after clearing the screen.
		System.out.println("\nCalculation Progress: " + percentage + "%");
	}
	
	/******************************************************************************
	* Submodule: calculateProgressPercentage                                      *
	* Import:    currentX (Integer)												  *
	* Export:    percentage (Integer)                                             *
	* Assertion: Calculates Progress Percentage based on how close currentX is to *
	*			 max.												  	          *
	******************************************************************************/
	private int calculateProgressPercentage(double currentX)
	{
		//Calculate the percentage, rounding to an integer.
		int percentage = (int) Math.round((currentX / max * 100));
		
		return percentage;
	}
}