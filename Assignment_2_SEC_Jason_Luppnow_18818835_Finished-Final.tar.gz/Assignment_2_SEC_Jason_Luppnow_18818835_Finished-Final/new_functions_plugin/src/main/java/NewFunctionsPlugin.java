/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         NewFunctionsPlugin.java                                       *
* Purpose:          Adds 2 new functions, Factorial & Fibonacci.				  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     14/10/2020                                                    *
**********************************************************************************/

//Define package for NewFunctionPlugin, this is the shared package for all plugins.
package org.plugins;

//Import Custom Packages
import org.calculator_api.CalculatorEventSource;
import org.calculator_api.CalculatorFunction;
import org.calculator_api.CalculatorPlugin;

/**********************************************************************************
* Public Class:    NewFunctionsPlugin                                             *
* Extends:         None     			     	    		    			      *
* Implements:      CalculatorPlugin          		                              *
* Assertion:       Responsible for adding new functions for the Interpreter.      *
**********************************************************************************/	
public class NewFunctionsPlugin implements CalculatorPlugin
{
	/**********************************
	*           Classfields           *
	**********************************/
	private CalculatorEventSource api;
	
	/******************************************************************************
	* Submodule: start                                                            *
	* Import:    inApi (CalculatorEventSource)									  *
	* Export:    None                                                             *
	* Assertion: Registers plugin with API.						    	          *
	******************************************************************************/
	@Override
	public void start(CalculatorEventSource inApi)
	{
		//Set the classfield.
		api = inApi;
	}

	/******************************************************************************
	* Submodule: factorial                                                        *
	* Import:    x (Double) 													  *
	* Export:    Double					                                          *
	* Assertion: Marks itself with CalculatorFunction annotation and calculates   *
	*            the factorial of the import parameter.			    	          *
	******************************************************************************/
	@CalculatorFunction
	public static double factorial(double x)
	{
		//Round the double.
		int roundedX = (int) Math.round(x);

		int i, factorialResult = 1;

		//Loop till roundedX, incrementing by 1.
		for (i = 1; i <= roundedX; i++)
		{
			factorialResult = factorialResult * i;
		}

		//Typecast back to double.
		return ((double)factorialResult);
	}

	/******************************************************************************
	* Submodule: fibonacci                                                        *
	* Import:    x (Double)  													  *
	* Export:    fibonacciResult (Integer)                                        *
	* Assertion: Marks itself with CalculatorFunction annotation and returns the  *
	*			 fibonacci sequence result using the import parameter. Uses the   *
	*			 recursive solution to calculate fibonacci.			              *
	******************************************************************************/
	@CalculatorFunction
	public static int fibonacci(double x)
	{
		//Typecast & round to Int.
		int roundedX = (int) Math.round(x);

		int fibonacciResult;

		if (roundedX <= 1)
		{
			fibonacciResult = roundedX;
		}
		else
		{
			fibonacciResult = fibonacci(roundedX - 1) + fibonacci(roundedX - 2);
		}

		return fibonacciResult;
	}
}