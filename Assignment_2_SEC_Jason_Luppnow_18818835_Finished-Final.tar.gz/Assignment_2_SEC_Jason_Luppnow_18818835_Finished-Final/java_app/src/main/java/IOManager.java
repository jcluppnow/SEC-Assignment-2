/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         IOManager.java                                                *
* Purpose:          Responsible for retrieving input from Console.				  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     10/10/2020                                                    *
**********************************************************************************/

//Define the package, this is the main source code package.
package org.example;

//Import Java Packages
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**********************************************************************************
* Public Class:    IOManager                                                      *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Responsible for retrieving input from Console.                 *
**********************************************************************************/
public class IOManager {

	/**********************************
	*           Classfields           *
	**********************************/
    private static String CLEARSCREEN = "\033[H\033[2J";
    private Scanner sc;

    /******************************************************************************
    * Submodule: IOManager (Default Constructor)                                  *
    * Import:    None 															  *
    * Export:    None                                                             *
    * Assertion: Creates the scanner to be used by all input methods. 	          *
    ******************************************************************************/
    public IOManager()
    {
        //Create a scanner to read input.
        sc = new Scanner(System.in);
    }
    
    /******************************************************************************
    * Submodule: getIntegerInput                                                  *
    * Import:    None 															  *
    * Export:    integerInput (Integer)                                           *
    * Assertion: Returns a valid integer from the command line.       	          *
    ******************************************************************************/
    public int getIntegerInput()
    {
        boolean validInput = false;
        int integerInput = 0;

        //Loop until a numerical input is recieved.
        while (!validInput)
        {
            try
            {            
                System.out.print("INPUT: ");
                
                //Convert the Integer to a String.
                integerInput = Integer.parseInt(sc.nextLine());
                
                //Set the boolean to valid.
                validInput = true;
            }
            catch (NumberFormatException invalidNumberFormat)
            {
                //The user has entered something non-numerical.
                System.out.println("\nInvalid Number, must be numerical, re-enter.");
            }
            catch (NoSuchElementException invalidInputLineException)
            {
                //No line was found inside scanner.
                System.out.println("\nInvalid Input, must not be empty, re-enter.");
            }
        }

        return integerInput;
    }

    /******************************************************************************
    * Submodule: getDoubleInput                                                   *
    * Import:    None 															  *
    * Export:    doubleInput (Double)                                             *
    * Assertion: Returns a valid double from the command line.       	          *
    ******************************************************************************/
    public double getDoubleInput()
    {
        boolean validInput = false;
        double doubleInput = 0.0;

        while (!validInput)
        {
            //Loop until a numerical input is recieved.
            try
            {
                System.out.print("INPUT: ");
                
                //Convert the Integer to a String.
                doubleInput = Double.parseDouble(sc.nextLine());
                
                //Set the boolean to valid.
                validInput = true;
            }
            catch (NumberFormatException invalidNumberFormat)
            {
                //The user has entered something non-numerical and it couldn't be
                //parsed to a double.
                System.out.println("\nInvalid Number, must be numerical, re-enter.");
            }
            catch (NullPointerException nullString)
            {
                //The user has somehow entered a null string.
                System.out.println("\nInvalid Number, must not be empty, re-enter.");
            }
            catch (NoSuchElementException invalidInputLineException)
            {
                //No line was found inside scanner.
                System.out.println("\nInvalid Input, must not be empty, re-enter.");
            }
        }

        return doubleInput;
    }

    /******************************************************************************
    * Submodule: getStringInput                                                   *
    * Import:    None 															  *
    * Export:    stringInput (String)                                             *
    * Assertion: Returns a valid string from the command line.      	          *
    ******************************************************************************/
    public String getStringInput()
    {	
        boolean validInput = false;
        String stringInput = "";

        //Loop until a valid string is entered.
        while (!validInput)
        {
            try
            {
                System.out.print("INPUT: ");      

                //Get the string in the buffer.  
                stringInput = sc.nextLine();
                validInput = true;
            }   
            catch (NoSuchElementException lineIsEmptyException)
            {
                //User didn't enter anything.
                System.out.println("\nInvalid Input, line must not be empty,re-enter.");
            } 
        }

        return stringInput;
    }
	
    /******************************************************************************
    * Submodule: clearScreen                                                      *
    * Import:    None 															  *
    * Export:    None                                                             *
    * Assertion: Resets the screan and flushes the output stream.   	          *
    ******************************************************************************/
	public void clearScreen()
    {
        //Print out the constant string - CLEARSCREEN.
        System.out.println(CLEARSCREEN);
        
        //Flush the output stream.
        System.out.flush();
    }
}
