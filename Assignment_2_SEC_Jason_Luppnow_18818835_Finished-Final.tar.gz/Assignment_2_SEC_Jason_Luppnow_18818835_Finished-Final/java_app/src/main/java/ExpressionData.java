/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ExpressionData.java                                           *
* Purpose:          Model class to represent an expression and it's parameters.   *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package, this is the main package for the application code.
package org.example;

/**********************************************************************************
* Public Class:    ExpressionData                                                 *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Model class to represent an expression and it's parameters.    *
**********************************************************************************/
public class ExpressionData
{
	/**********************************
	*           Classfields           *
	**********************************/
	private String equation;
	private double minimum, maximum, increment;
	
	/******************************************************************************
	* Submodule: ExpressionData (Alternate Constructor)                           *
	* Import:    inEquation (String), inMinimum (Double), inMaximum (Double)      *
	*			 inIncrement (Double)											  *
	* Export:    None                                                             *
	* Assertion: Constructs an ExpressionData object using imports. 	          *
	******************************************************************************/
	public ExpressionData(String inEquation, double inMinimum, double inMaximum, double inIncrement)
	{
		//Set the classfields.
		equation = inEquation;
		minimum = inMinimum;
		maximum = inMaximum;
		increment = inIncrement;
	}
	
	/******************************************************************************
	*                                 ACCESSORS                                   *
	*******************************************************************************
	*            Responsible for accessing all ExpressionData classfields.        *
	******************************************************************************/
	public String getEquation() { return equation; }
	
	public double getMinimum() { return minimum; }
	
	public double getMaximum() { return maximum; }
	
	public double getIncrement() { return increment; }
}