/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ExpressionHandlerException.java                               *
* Purpose:          Reflects problems happening within the Expression Handler.    *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Expression Handler Exception, this package is for
//files related to the application.
package org.example;

/**********************************************************************************
* Public Class:    ExpressionHandlerException                                     *
* Extends:         Exception  			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Reflects problems happening within the Expression Handler.     *
**********************************************************************************/
public class ExpressionHandlerException extends Exception
{
	/******************************************************************************
    * Submodule: ExpressionHandlerException (Alternate Constructor)               *
    * Import:    errorMessage (String)											  *
    * Export:    None                                                             *
    * Assertion: Passes the error message to the super Exception class.           *
    ******************************************************************************/
	public ExpressionHandlerException(String errorMessage)
	{
		super(errorMessage);
	}
}