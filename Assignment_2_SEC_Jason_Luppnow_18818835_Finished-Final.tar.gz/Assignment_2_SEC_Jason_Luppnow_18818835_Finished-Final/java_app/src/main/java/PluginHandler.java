/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         PluginHandler.java                                            *
* Purpose:          Responsible for loading, adding and removing Plugins.		  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     12/10/2020                                                    *
**********************************************************************************/

//Define the plugin for Plugin Handler.
package org.example;

//Import Java Packages
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.lang.reflect.*;

//Import Custom Packages
import org.script.executor.ScriptExecutor;
import org.calculator_api.CalculatorPlugin;
import org.calculator_api.CalculatorFunction;

/**********************************************************************************
* Public Class:    PluginHandler                                                  *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Responsible for loading, adding and removing Plugins.          *
**********************************************************************************/
public class PluginHandler {

	/**********************************
	*           Classfields           *
	**********************************/
	private ScriptExecutor scriptExecutor;
    private ArrayList<String> plugins;
	private IOManager ioManager;
	
	/******************************************************************************
	* Submodule: PluginHandler (Alternate Constructor)							  *
	* Import:    inIOManager (IOManager), inScriptExecutor (ScriptExecutor)		  *
	* Export:    None                                                             *
	* Assertion: Constructs an instance of PluginHandler with imports.            *
	******************************************************************************/
    public PluginHandler(IOManager inIOManager, ScriptExecutor inScriptExecutor) throws PluginHandlerException
    {
		//Check if the imports are valid.
		if (inIOManager == null || inScriptExecutor == null)
		{
			//Throw an exception based on which is invalid.
			if (inIOManager == null)
			{
				throw new PluginHandlerException("IO Manager is invalid - Plugin Handler Alternate Constructor.");
			}
			else
			{
				throw new PluginHandlerException("Script Executor is invalid - Plugin Handler Alternate Constructor.");
			}
		}
		else
		{
			//Initialize the classfields after validity checks.
			ioManager = inIOManager;
			scriptExecutor = inScriptExecutor;
			plugins = new ArrayList<>();
		}
    }

	/******************************************************************************
	* Submodule: displayPlugins                                                   *
	* Import:    None 															  *
	* Export:    None                                                             *
	* Assertion: Displays the plugin menu options and gets the choice.            *
	******************************************************************************/
    public void displayPlugins()
    {
        int choice = 0;

		//Loop until exit is selected.
        do 
        {
			//Wipe the screen. Not essential but makes it look nice.
            ioManager.clearScreen();
            
			//Displays all plugins in list.
			printPlugins();

			//Display the 3 menu options.
            System.out.println("1. Add a Plugin.");
            System.out.println("2. Remove a Plugin.");
			System.out.println("3. Exit.");
			
			//Get the selection from  the user.
            choice = ioManager.getIntegerInput();

			//Process the selection.
            handleInput(choice);
        }
        while (choice != 3);	
		//Loop until a valid selection has occurred.
    }

	/******************************************************************************
	*                                 ACCESSORS                                   *
	*******************************************************************************
	*        Responsible for accessing all of Plugin Handler classfields.         *
	******************************************************************************/
	public ArrayList<String> getListOfPlugins()
	{
		return plugins;
	}
	
	/******************************************************************************
	* Submodule: getReflectedPlugins                                              *
	* Import:    pluginNames (ArrayList of Strings) 							  *
	* Export:    instantiatedPlugins (ArrayList of Calculator Plugins)            *
	* Assertion: Uses reflection to load plugins and check for any extra          *
	*			 Calculator functions that need to be added to Jython.            *
	******************************************************************************/
	public ArrayList<CalculatorPlugin> getReflectedPlugins(ArrayList<String> pluginNames)
	{
		//Create the list to be returned.
		ArrayList<CalculatorPlugin> instantiatedPlugins = new ArrayList<CalculatorPlugin>();
		
		//Iterate over all the plugin names.
		for (String currentPluginName : pluginNames)
		{
			try
			{
				//? - Class has a generic type parameter that identifies at compile time
				//which class if refers to. Since we don't know what class it will be,
				//we use the ? wildcard.
				Class<?> pluginClass = Class.forName(currentPluginName);
				
				//Get the Constructor
				Constructor alternateConstructor = pluginClass.getConstructor();
				
				//Call the constructor
				CalculatorPlugin newPlugin = (CalculatorPlugin) (alternateConstructor.newInstance());
				

				//Check for any annotated methods that are functions.
				processPluginForNewFunctions(pluginClass);

				//Check if the new plugin has been instantiated correctly.
				if (newPlugin != null)
				{
					//Add the newly created plugin.
					instantiatedPlugins.add(newPlugin);
				}
			}
			catch (LinkageError linkageException)
			{
				System.out.println(currentPluginName + " has some dependency on another class that was changed after compliation.");
			}
			catch (ClassNotFoundException classNotFoundException)
			{
				System.out.println(currentPluginName + " cannot be located.");
				System.out.println("Message: " + classNotFoundException.getMessage());
				classNotFoundException.printStackTrace();
			}
			catch (NoSuchMethodException noMethodFoundException)
			{
				System.out.println("\nCouldn't find method for : " + currentPluginName);
			}
			catch (SecurityException securityException)
			{
				System.out.println("\nPermission denied when trying to access : " + currentPluginName);
			}
			catch (IllegalAccessException illegalAccessException)
			{
				System.out.println("\nUnderlying constructor for " + currentPluginName + " is inaccessible.");
			}
			catch (IllegalArgumentException illegalArgumentException)
			{
				System.out.println("\nNumber of parameters differ for " + currentPluginName + " constructor.");
			}
			catch (InstantiationException instantiationException)
			{
				System.out.println("\n" + currentPluginName + " class is an abstract class and cannot be instantiated.");
			}
			catch (InvocationTargetException constructorException)
			{
				System.out.println("\n" + currentPluginName + "'s Constructor has thrown an exception.");
			}
		}
		
		return instantiatedPlugins;
	}
	
	/******************************************************************************
	* Submodule: handleInput                                                      *
	* Import:    choice (Integer)												  *
	* Export:    None                                                             *
	* Assertion: Controls what happens based on choice.		        	          *
	******************************************************************************/
    private void handleInput(int choice)
    {
		//React to the choice.
        switch (choice)
        {
            case 1:
				//Load the code to add a new plugin.
                addNewPlugin();
                break;

            case 2:
				
				//Display the plugins.
                printPlugins();
                System.out.println("\nWhat plugin would you like to remove?");
				
				//Get the plugin to remove.
                int pluginChoice = ioManager.getIntegerInput();
				
				//Call to remove the plugin.
                removePlugin(pluginChoice);
                break;
            
			default:
				//3 is a valid choice, exit.
				if (choice != 3)
				{
					System.out.println("\n" + choice + " is an invalid Choice.");
				} 
        }
    }

	/******************************************************************************
	*                                MUTATORS                                     *
	*******************************************************************************
	*           Responsible for setting all of Plugin Handler classfields.        *
	******************************************************************************/
    private void addNewPlugin()
    {
		//Clear the screen - Not essential but looks nice.
        ioManager.clearScreen();

		//Both the package & plugin name is required to be able to locate the
		//Plugin for reflection.
		System.out.println("Enter Plugin Package, leave empty for no package.");
		String packageName = ioManager.getStringInput();
        
		System.out.println("\nEnter plugin name.");
        String pluginName = ioManager.getStringInput();

        //Not gonna bother checking if its a valid plugin here.
        //Since we are going to reflect it which will 
        //be able to handle this exception.
        if (pluginName.equals(""))
        {
            System.out.println("\nPlugin name cannot be empty.");
        }
        else
        {
            plugins.add(packageName + "." + pluginName);
        }
    }

    private void removePlugin(int choice)
    {
		//Adjust the selection for 0-based indexing.
        plugins.remove(choice - 1);
    }

	/******************************************************************************
	* Submodule: printPlugins                                                     *
	* Import:    None 															  *
	* Export:    None                                                             *
	* Assertion: Display list of Plugins if there are any.		    	          *
	******************************************************************************/
    private void printPlugins()
    {
		System.out.println("Plugins: ");
		
		//Check if there are any plugins loaded.
		if (plugins.isEmpty())
		{
			//Print that there are none.
			System.out.println("\tNo Plugins loaded.\n");
		}
		else
		{
			//From 1 to infinity print the plugins.
			int pluginNumber = 1;

			//Iterate over every plugin.
			for (String currentPlugin : plugins)
			{
				System.out.println("\t" + pluginNumber + ": " + currentPlugin);
			}
			System.out.print("\n");
		}
	}

	/******************************************************************************
	* Submodule: processPluginForNewFunctions                                     *
	* Import:    pluginClass (Class of Wildcard Generic Type) 					  *
	* Export:    None                                                             *
	* Assertion: Checks if there are any annotated functions matching the         *
	*			 Calculator Function annotation and registers the function with   *
	*			 the Python Interpreter.						    	          *
	******************************************************************************/
	private void processPluginForNewFunctions(Class<?> pluginClass)
	{
		//Get the package name for this class.
		String className = pluginClass.getName();

		//Iterate over all Methods in Plugin class.
		for (Method currentPluginMethod : pluginClass.getMethods())
		{
			//Get the Annotation for this method.
			Annotation currentAnnotation = currentPluginMethod.getAnnotation(CalculatorFunction.class);

			//Check if the annotation returned is of type Calculator Function.
			if (currentAnnotation instanceof CalculatorFunction)
			{
				//Get the method name of the current plugin.
				String methodName = currentPluginMethod.getName();

				//Add this function to Python Interpreter.
				scriptExecutor.addFunction(className, methodName);
			}
		}
	}
}
