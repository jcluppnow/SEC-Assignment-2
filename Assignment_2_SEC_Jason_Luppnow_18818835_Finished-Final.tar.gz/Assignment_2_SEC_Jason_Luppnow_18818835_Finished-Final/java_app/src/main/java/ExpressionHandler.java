/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ExpressionHandler.java                                        *
* Purpose:          Manages the creation and validation of an Expression.		  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Expression Handler, this package is for files related
//to remaining application functionality.
package org.example;

//Import Custom Packages
import org.calculator_api.CalculatorEventSource;
import org.script.executor.ScriptExecutor;

/**********************************************************************************
* Public Class:    ExpressionHandler                                              *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Manages the creation and validation of an Expression.          *
**********************************************************************************/
public class ExpressionHandler
{
	/**********************************
	*           Classfields           *
	**********************************/
	private CalculatorEventSource calculatorEventSource;
	private ScriptExecutor scriptExecutor;
	private IOManager ioManager;
	
	
	/******************************************************************************
	* Submodule: ExpressionHandler (Alternate Constructor)                        *
	* Import:    inIOManager (IOManager), inCalculatorEventSource                 *
	* 			 (CalculatorEventSource), inScriptExecutor (ScriptExecutor)       *
	* Export:    None                                                             *
	* Assertion: Constructs a new Expression Handler object using imports.        *
	******************************************************************************/
	public ExpressionHandler(IOManager inIOManager, CalculatorEventSource inCalculatorEventSource, 
		ScriptExecutor inScriptExecutor) throws ExpressionHandlerException
	{
		//Check if the imports are valid.
		if (inIOManager == null || inCalculatorEventSource == null || inScriptExecutor == null)
		{
			//Depending on which import is invalid, provide a different error message to ExpressionHandlerException.
			if (inIOManager == null)
			{
				throw new ExpressionHandlerException("Invalid IO Manager parameter - Expression Handler Alternate Constructor.");
			}
			else if (inCalculatorEventSource == null)
			{
				throw new ExpressionHandlerException("Invalid Calculator Event Source - Expression Handler Alternate Constructor.");
			}
			else
			{
				throw new ExpressionHandlerException("Invalid Script Executor - Expression Handler Alternate Constructor.");
			}
		}
		else
		{
			//Set the classfields.
			ioManager = inIOManager;
			calculatorEventSource = inCalculatorEventSource;
			scriptExecutor = inScriptExecutor;
		}
	}
	
	/******************************************************************************
	* Submodule: getExpressionData                                                *
	* Import:    None 															  *
	* Export:    ExpressionData							                          *
	* Assertion: Creates a new Expression Data object using parameters from user. *
	******************************************************************************/
	public ExpressionData getExpressionData()
	{
		//Clear the screen - Not essential but looks nice.
		ioManager.clearScreen();

		//Retrieve all valid parameters from the user.
		System.out.println("Enter the Equation.");
		String equation = ioManager.getStringInput();
		
		//Get the minimum from the user.
		System.out.println("\nEnter the minimum x value.");
		double minimumX = ioManager.getDoubleInput();
		
		//Get max and check if it is greater than min.
		double maximumX = getMaximumXValue(minimumX);
		
		//Get the increment.
		System.out.println("\nEnter the incrementing value.");
		double increment = ioManager.getDoubleInput();
		
		//Return a newly created Expression Data object.
		return new ExpressionData(equation, minimumX, maximumX, increment);
	}
	
	/******************************************************************************
	* Submodule: runExpression                                                    *
	* Import:    expressionData (ExpressionData)								  *
	* Export:    None                                                             *
	* Assertion: Iterates through paramaters (min -> max using increment). Each   *
	*			 iteration submit the expression for the Scripting engine to      *
    *			 evaluate.                                                        *
	******************************************************************************/
	public void runExpression(ExpressionData expressionData)
	{
		//Define local variables.
		String equation;
		double x, minimumX, maximumX, increment, result;
		
		//Initialise values.
		equation = expressionData.getEquation();
		minimumX = expressionData.getMinimum();
		maximumX = expressionData.getMaximum();
		increment = expressionData.getIncrement();
		
		//Notify Input Value Observers that the user has accepted the Expression parameters.
		//Meaning that the above values are now final and won't change till next run.
		calculatorEventSource.notifyInputValuesObservers(equation, minimumX, maximumX, increment);
		
		//Loop until x is equal to maximumX.
		for (x = minimumX; x <= maximumX; x+= increment)
		{
			//Replace x string with the x value.
			//Have 2 of these methods to allow uppercase or lowercase x.
			String xAsString = Double.toString(x);
			String substitutedEquation = equation.replace("x", xAsString);
			substitutedEquation = substitutedEquation.replace("X", xAsString);

			//Send the expression to the PythonIntepretor and retrieve the result.
			result = scriptExecutor.runScript(substitutedEquation);

			//Progress Observers wants updates as to progress of this loop.
			//Updates are so it knows how close we are to maximum.
			//This occurs at the as soon as the script is run as this is a timing requirement.
			calculatorEventSource.notifyProgressObservers(x);

			//Notify all ResultObservers with the current x value and the new result.
			calculatorEventSource.notifyResultObservers(x, result);
		}
	}
		
	/******************************************************************************
	* Submodule: getMaximumXValue                                                 *
	* Import:    minimumX (Double)												  *
	* Export:    maximumX (Double)                                                *
	* Assertion: Requests maximum value until a valid value has be entered.       *
	******************************************************************************/
	private double getMaximumXValue(double minimumX)
	{	
		double maximumX;
		
		//Loop until maximum is greater than min.
		do 
		{
			System.out.println("\nEnter the maximum x value.");

			//Get max from the user via command line.
			maximumX = ioManager.getDoubleInput();
			
			//Check if max is bigger.
			if (maximumX <= minimumX)
			{
				//Output error message that it isn't.
				System.out.println("Invalid Input for Maximum X, must be greater than: " + minimumX);
			}
		}
		while (maximumX <= minimumX);
		//Loop until this condition is true.
		
		return maximumX;
	}
}