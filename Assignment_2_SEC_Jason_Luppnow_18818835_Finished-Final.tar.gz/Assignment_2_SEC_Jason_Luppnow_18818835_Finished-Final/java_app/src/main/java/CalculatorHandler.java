/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CalculatorHandler.java                                        *
* Purpose:          Represents the main facet of the API, everything starts from  *
*					here.                                   					  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Calculator Handler.
package org.example;

//Import Java Packages
import java.util.ArrayList;

//Import Custom Packages
import org.calculator_api.CalculatorEventSource;
import org.calculator_api.CalculatorPlugin;
import org.script.executor.ScriptExecutor;

/**********************************************************************************
* Public Class:    CalculatorHandler                                              *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Represents the main facet of the API, API usage begins at the  *
*				   loadOptions.                                                   *
**********************************************************************************/
public class CalculatorHandler
{
	/******************************************************************************
	* Submodule: loadOptions                                                      *
	* Import:    None 															  *
	* Export:    None                                                             *
	* Assertion: Construct required objects and start load the main menu.	      *
	******************************************************************************/
    public void loadOptions()
	{
		try
		{
			//Create the api.
			CalculatorEventSource calculatorEventSource = new CalculatorEventSource();
			
			//Check if it was constructed. If not end the program.
			if (calculatorEventSource == null)
			{
				System.out.println("CalculatorEventSource is null, Shutting Down.");
			}
			else
			{
				//Construct the remaining Objects.
				ScriptExecutor scriptExecutor = new ScriptExecutor();
				IOManager ioManager = new IOManager();
				ExpressionHandler expressionHandler = new ExpressionHandler(ioManager, calculatorEventSource, scriptExecutor);
				PluginHandler pluginHandler = new PluginHandler(ioManager, scriptExecutor);

				//Display the menu.
				loadMenu(pluginHandler, ioManager, expressionHandler, calculatorEventSource);
			}

		}
		catch (ExpressionHandlerException expressionHandlerException)
		{
			//This will occur if the imports of the constructor are invalid.
			//More causes would be added in the future if this software was extended.
			System.out.println(expressionHandlerException.getMessage());
			System.out.println("Closing program, goodbye.");
		}
		catch (PluginHandlerException pluginHandlerException)
		{
			//This will occur if the imports of the constructor are invalid.
			//More causes would be added in the future if this software was extended.
			System.out.println(pluginHandlerException.getMessage());
			System.out.println("Closing program, goodbye.");
		}
    }

	/******************************************************************************
	* Submodule: loadMenu                                                         *
	* Import:    pluginHandler (PluginHandler), ioManager (IOManager),            *
	*			 expressionHandler (ExpressionHandler), calculatorEventSource     *
	*			 (CalculatorEventSource)	                                      *
	* Export:    None                                                             *
	* Assertion: Displays the main menu and loads the menu selection. 	          *
	******************************************************************************/
    private void loadMenu(PluginHandler pluginHandler, IOManager ioManager, ExpressionHandler expressionHandler, CalculatorEventSource calculatorEventSource)
    {
		int choice;
		
		//Loop until the user is done with the program.
		do
		{
			//Clears the screen, not required for functionality just for making it look nice.
			ioManager.clearScreen();

			//Display the 3 menu options.
			System.out.println("\n1. Manage Plugins");
			System.out.println("2. Evaluate expression.");
			System.out.println("3. Exit Program.");

			//Get which option the user wants.
			choice = ioManager.getIntegerInput();

			//React to the user's selection.
			handleMenuSelection(choice, pluginHandler, expressionHandler, calculatorEventSource);
		}
		while (choice != 3);
		//3 corresponds to the menu exit condition.
    }

	/******************************************************************************
	* Submodule: handleMenuSelection                                              *
	* Import:    choice (Integer), pluginHandler (PluginHandler),                 *
	*			 expressionHandler (ExpressionHandler), calculatorEventSource     *
	*			 (CalculatorEventSource)										  *
	* Export:    None                                                             *
	* Assertion: Controls what happens based on choice.			    	          *
	******************************************************************************/
    private void handleMenuSelection(int choice, PluginHandler pluginHandler, ExpressionHandler expressionHandler, CalculatorEventSource calculatorEventSource)
    {
		//Control what happens when the choice is entered.
        switch(choice)
        {
            case 1:
				//Simply prints all currently loaded plugins.
				pluginHandler.displayPlugins();
                break;

            case 2:
				//Proceeds to get an expression as well as min,max and increment values from the user.
                evaluateExpression(expressionHandler, pluginHandler, calculatorEventSource);
                break;

            default:
				//Check if the user has decided to exit.
				if (choice == 3)
				{
					//Print the exit message.
					System.out.println("Closing Program.");
				}
				else
				{
					//Output error message for invalid choice.
					System.out.println("Invalid Selection, Goodbye");
				}
        }
    }

	/******************************************************************************
	* Submodule: evaluateExpression                                               *
	* Import:    expressionHandler (ExpressionHandler) pluginHandler              *
	*			 (PluginHandler), calculatorEventSource (CalculatorEventSource)   *
	* Export:    None                                                             *
	* Assertion: Get the expression from the user and submit it for evaluation.   *
	******************************************************************************/
    private void evaluateExpression(ExpressionHandler expressionHandler, PluginHandler pluginHandler, CalculatorEventSource calculatorEventSource)
    {
		boolean validExpression = true;
		
		//Loop until the user has entered a valid expression.
		do
		{
			try
			{
				//Create the expression object.
				ExpressionData expressionData = expressionHandler.getExpressionData();
				
				//Print Expression Data and Check if user is happy with Expression.
				
				//Initialise Plugins
				initialisePlugins(pluginHandler, calculatorEventSource);
				
				//Then run the Expression
				expressionHandler.runExpression(expressionData);
			}
			catch (NullPointerException npe)
			{
				//Happens if the imports are null.
				validExpression = false;
				System.out.println("Invalid State of Imports.");
				throw new IllegalArgumentException("Invalid Expression Handler.");
			}
		}
		while (validExpression == false);
	}
	
	/******************************************************************************
	* Submodule: initialisePlugins                                                *
	* Import:    pluginHandler (PluginHandler), calculatorEventSource             *
	*			 (CalculatorEventSource)										  *
	* Export:    None                                                             *
	* Assertion: Load and run the plugins.						    	          *
	******************************************************************************/
	private void initialisePlugins(PluginHandler pluginHandler, CalculatorEventSource calculatorEventSource)
	{
		//Create the 2 lists, get the plugins list through reflection.
		ArrayList<String> pluginNames = pluginHandler.getListOfPlugins();
		ArrayList<CalculatorPlugin> plugins = pluginHandler.getReflectedPlugins(pluginNames);
		
		//Start the plugins running.
		for (CalculatorPlugin currentPlugin : plugins)
		{
			currentPlugin.start(calculatorEventSource);
		}
	}
}
