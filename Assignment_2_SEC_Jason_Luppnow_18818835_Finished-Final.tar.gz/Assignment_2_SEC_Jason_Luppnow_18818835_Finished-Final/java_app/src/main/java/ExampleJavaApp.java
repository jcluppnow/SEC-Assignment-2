/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         .java                                             *
* Purpose:          .                					  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     11/10/2020                                                    *
**********************************************************************************/

//Define the package for this class, main running files belong to this package.
package org.example;

//Import Java Packages
import java.util.*;

/**********************************************************************************
* Public Class:    ExampleJavaApp                                                 *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Starts the whole program.                                      *
**********************************************************************************/
public class ExampleJavaApp
{
	public static void main(String[] args)
	{
		//Create the application and start the running.
		try
		{
			CalculatorHandler calculatorHandler = new CalculatorHandler();
			calculatorHandler.loadOptions();
		}
		catch (NullPointerException nullPointerException)
		{
			//In case a NPE was to occur from calculator handler being null. Not likely at all though.
			System.out.println("Unable to load program, Goodbye.");
		}
	}
}