/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         PluginHandlerException.java                                   *
* Purpose:          Reflects problems happening within the Plugin Handler.        *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     22/10/2020                                                    *
**********************************************************************************/

//Define the package for Plugin Handler Exception, this package is for
//files related to the application.
package org.example;

/**********************************************************************************
* Public Class:    PluginHandlerException                                         *
* Extends:         Exception  			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Reflects problems happening within the Plugin Handler.         *
**********************************************************************************/
public class PluginHandlerException extends Exception
{
	/******************************************************************************
    * Submodule: PluginHandlerException (Alternate Constructor)                   *
    * Import:    errorMessage (String)											  *
    * Export:    None                                                             *
    * Assertion: Passes the error message to the super Exception class.           *
    ******************************************************************************/
	public PluginHandlerException(String errorMessage)
	{
		super(errorMessage);
	}
}