/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ScriptExecutor.java                                        *
* Purpose:          This class takes in a script and returns a result.			  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     19/10/2020                                                    *
**********************************************************************************/

//Define the package for ScriptExecutor
package org.script.executor;

//Import Packages from Jython Dependency added in Gradle.
import org.python.core.*;
import org.python.util.*;

/**********************************************************************************
* Public Class:    ScriptExecutor                                                 *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       This class uses jython to evaluate python scripts.             *
**********************************************************************************/
public class ScriptExecutor
{
	/**********************************
	*           Classfields           *
	**********************************/
	private PythonInterpreter interpreter;

	/******************************************************************************
	* Submodule: ScriptExecutor (Default Constructor)                             *
	* Import:    None 															  *
	* Export:    None                                                             *
	* Assertion: Initialise the classfields.					    	          *
	******************************************************************************/
	public ScriptExecutor()
	{
		//Initialise the interpreter with an empty local namespace.
		interpreter = new PythonInterpreter();
	}

	/******************************************************************************
	* Submodule: runScript                                                        *
	* Import:    expression (String)											  *
	* Export:    result (Double)                                                  *
	* Assertion: Evaluate the script and convert the result into a Java double.   *
	******************************************************************************/
	public double runScript(String expression)
	{
		double result = 0.0;

		try
		{
			//Evaluates the string as a Python  expression and returns the result.
			result = ((PyFloat) interpreter.eval("float(" + expression + ")")).getValue();
	
		}
		catch (PyException newPythonException)
		{
			//Check if the user exited manually.
			if (PyException.exceptionClassName(newPythonException.type).equalsIgnoreCase("exceptions.SystemExit")) 
			{
				System.out.println("Shutting Down due to System Exit.");
			}
			else 
			{
				// Prints stack trace to the interpreter error stream.
				System.out.println("\nInvalid Expression: " + expression);
				newPythonException.printStackTrace(); 
			}
		}

		return result;
	}

	/******************************************************************************
	* Submodule: addFunction                                                      *
	* Import:    className (String), methodName (String)  						  *
	* Export:    None                                                             *
	* Assertion: Converts the parameters into an import string and execute it     *
	*			 using the python interpreter. Doing this means we can now call   *
 	* 			 the binded function within expressions.				          *
	******************************************************************************/
	public void addFunction(String className, String methodName)
	{
		//System.out.println("Checking Validity of add Function\nExpected pluginPackage: org.plugins");
		//System.out.println("Plugin package: " + pluginPackage + " ClassName: " + className + " Method Name: " + methodName);
		
		//Combine all parameters into one import string.
		String importString = "from " + className + " import " + methodName;

		//Execute the import string using the interpreter.
		//Executes a string of Python source in the local name space.
		try
		{
			interpreter.exec(importString);
			System.out.println("\nSuccessfully added Function: " + methodName + " from " + className + " Class");
		}
		catch (PyException newPythonException)
		{
			//Check if the user wasn't exited manually.
			if (PyException.exceptionClassName(newPythonException.type).equalsIgnoreCase("exceptions.SystemExit")) 
			{
				System.out.println("Shutting Down due to System Exit.");
			}
			else 
			{
				// Prints stack trace to the interpreter error stream.
				System.out.println("\nUnable to add import to Python Environment: " + importString);
				newPythonException.printStackTrace(); 
			}
		}
	}
}