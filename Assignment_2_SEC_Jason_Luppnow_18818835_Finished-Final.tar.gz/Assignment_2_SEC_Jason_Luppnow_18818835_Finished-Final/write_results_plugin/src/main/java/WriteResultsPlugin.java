/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         WriteResultsPlugin.java                                       *
* Purpose:          Writes results to CSV using Apache Commons CSV.				  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     14/10/2020                                                    *
**********************************************************************************/

//NOTE - Results appear in the java_app subproject as this is where main is.

//Define the package for WriteResultsPlugin, this is the shared package for all 
//plugins.
package org.plugins;

//Import Java Packages.
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

//Import packages from Apacahe Commons CSV added in Gradle Dependency.
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

//Import Custom Packages
import org.calculator_api.CalculatorEventSource;
import org.calculator_api.CalculatorPlugin;
import org.calculator_api.ResultObserver;

/**********************************************************************************
* Public Class:    WriteResultsPlugin                                             *
* Extends:         None     			     	    		    			      *
* Implements:      CalculatorPlugin, ResultObserver	                              *
* Assertion:       Recieves results and writes them to a CSV file.                *
**********************************************************************************/
public class WriteResultsPlugin implements CalculatorPlugin, ResultObserver
{
	/**********************************
	*           Classfields           *
	**********************************/
	private String fileName;
	private CalculatorEventSource api;
	
	/******************************************************************************
	* Submodule: start                                                            *
	* Import:    inApi (CalculatorEventSource)									  *
	* Export:    None                                                             *
	* Assertion: Registers plugin with API.						    	          *
	******************************************************************************/
	@Override
	public void start(CalculatorEventSource inApi)
	{
		//Set the classfields.
		fileName = "Results.csv";
		api = inApi;

		//Register the Plugin as an Result Observer.
		api.addResultObserver(this);
	}
	
	/******************************************************************************
	* Submodule: recieveResultsCallback                                           *
	* Import:    x (Double), result (Double)									  *
	* Export:    None                                                             *
	* Assertion: Recieves imports from API and writes them to CSV.   	          *
	******************************************************************************/
	@Override
	public void recieveResultsCallback(double x, double result)	
	{
        try (
			//Open the file in append mode.
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(fileName), StandardOpenOption.APPEND, StandardOpenOption.CREATE);

			//Create the printer.
            CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withDelimiter(','));
		) 
		{
			//Print the record.
			csvPrinter.printRecord(Double.toString(x), Double.toString(result));
            
			//Then flush the underlying stream.
			csvPrinter.flush();            
		}
		catch (IOException ioException)
		{
			//Thrown if the optional header cannot be printed or an I/O error occurred
			//while trying to print the record or flush the printer stream.
			System.out.println("Error writing to file: " + fileName + "\n");
		}
		catch (IllegalArgumentException  invalidParameters)
		{
			//Thrown if the parameters of the format are inconsistent.
			//Or will be thrown if out/format is null.
			System.out.println("Invalid Parameters, X: " + x + " Result: " + result + "\n");
		}
		catch (UnsupportedOperationException invalidOption)
		{
			//If an unsupported option was specified when creating the BufferedWriter.
			//Not like to happen as I have chosen the options. But I will catch it 
			//none the less.
			System.out.println("Invalid Parameters for Buffered Writer.\n");
		}
		catch (SecurityException securityException)
		{
			//Usually occurs when permission is denied.
			//Since we are the ones creating this file its unlikely this will occur.
			//But I want to err on the side of caution
			System.out.println("Unable to access: " + fileName + "due to Security Manager denial of access.\n");
		}
	}
}