/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CPluginControl.java                                           *
* Purpose:          Loads the static initializer and acts as the interface with   *
*					C++ plugin.													  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     20/10/2020                                                    *
**********************************************************************************/

//Define the package for CPluginControl, this is the shared package for all 
//plugins.
package org.cplugin;

//Import Custom Packages
import org.calculator_api.CalculatorEventSource;
import org.calculator_api.CalculatorPlugin;
import org.calculator_api.ResultObserver;

/**********************************************************************************
* Public Class:    CPluginControl                                                 *
* Extends:         None        	    		    			          *
* Implements:      CalculatorPlugin, ResultObserver                               *
* Assertion:       Defines the fields & native methods for the C plugin to use.   *
**********************************************************************************/
public class CPluginControl implements CalculatorPlugin, ResultObserver
{
	//Static Initializer (runs when the class is loaded).
	static 
	{
		//Load the native code.
		System.loadLibrary("example_c_library");
	}

	/**********************************
	*           Classfields           *
	**********************************/
	private String fileName;
	private CalculatorEventSource api;
	
	//Native methods.
	//Native methods have no definition which will be provided by example_c_library.
	@Override
	public native void start(CalculatorEventSource inApi);

	@Override
	public native void recieveResultsCallback(double x, double result);
}
