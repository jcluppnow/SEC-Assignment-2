#include <jni.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

// This construct is needed to make the C++ compiler generate C-compatible compiled code.
extern "C" 
{
    /******************************************************************************
    * Submodule: Java_org_cplugin_CPluginControl_start                            *
    * Import:    env (Pointer to JNIEnv), thisObject (jobject), inApi (jobject)	  *
    * Export:    None                                                             *
    * Assertion: Responsible for setting classfields, and adding plugin to event  *
    *            source. Everything is converted to be done by C.    	          *
    ******************************************************************************/
    JNIEXPORT void JNICALL Java_org_cplugin_CPluginControl_start(JNIEnv *env, jobject thisObject, jobject inApi)
    {

        //Get the main class - using the instance from thisObject.
        jclass mainCls = env->GetObjectClass(thisObject);

        //Check that main class was retrieved correctly.
        if (mainCls == NULL)
        {
            cout << "Main Class is null, and start can't proceed.";\
            //Need this to ensure that the buffer is flushed and stored output will
            //be displayed properly.
            fflush(stdout);
        }
        else
        {
            const char* fileNameCString = "CPluginResults.csv";

            //Obtain the field ID of fileName.
            jfieldID fileNameFieldID = env->GetFieldID(mainCls, "fileName", "Ljava/lang/String;");
            
            //Convert the C String to a Java String.
            jstring fileNameJavaString = env->NewStringUTF(fileNameCString);

            if (fileNameFieldID == NULL)
            {
                cout << "File Name Classfield ID is null and therefore can't be mutated.";
                //Need this to ensure that the buffer is flushed and stored output will
                //be displayed properly.
                fflush(stdout);
            }
            else
            {
                if (fileNameJavaString == NULL)
                {
                    cout << "File Name Java String is null and therefore we can't use it to set File name classfield.";
                    //Need this to ensure that the buffer is flushed and stored output will
                    //be displayed properly.
                    fflush(stdout);
                }
                else
                {
                    //Overwrite the fileName instance field with the new fileName.
                    env->SetObjectField(thisObject, fileNameFieldID, fileNameJavaString);
                    
                    //Obtain the field ID of api.
                    jfieldID apiFieldID = env->GetFieldID(mainCls, "api", "Lorg/calculator_api/CalculatorEventSource;");

                    if (apiFieldID == NULL)
                    {
                        cout << "API Field ID is null and can't be used to mutate the API classfield.";
                        //Need this to ensure that the buffer is flushed and stored output will
                        //be displayed properly.
                        fflush(stdout);
                    }
                    else
                    {
                        //Overwrite the api instance field with inApi.
                        env->SetObjectField(thisObject, apiFieldID, inApi);

                        //Read the api instance field.
                        jobject api = env->GetObjectField(thisObject, apiFieldID);

                        if (api == NULL)
                        {
                            cout << "Couldn't retrieve API from classfield, meaning it can't be used to addResult Observers.";
                            //Need this to ensure that the buffer is flushed and stored output will
                            //be displayed properly.
                            fflush(stdout);
                        }
                        else
                        {
                            //Get the api class using the api instance field.
                            jclass apiCls = env->GetObjectClass(api);

                            if (apiCls == NULL)
                            {
                                cout << "Api class is null.";
                                //Need this to ensure that the buffer is flushed and stored output will
                                //be displayed properly.
                                fflush(stdout);
                            }
                            else
                            {
                                //Get the methodID which performs a lookup for the method in the given class.
                                jmethodID addResultObserverMethodID = env->GetMethodID(apiCls, "addResultObserver", "(Lorg/calculator_api/ResultObserver;)V");

                                if (addResultObserverMethodID == NULL)
                                {
                                    cout << "addResultObserver method not found.";
                                    //Need this to ensure that the buffer is flushed and stored output will
                                    //be displayed properly.
                                    fflush(stdout);
                                }
                                else
                                {
                                    //Then call CallVoidMethod - pass the object to be added, the method id and the arguments.
                                    env->CallVoidMethod(api, addResultObserverMethodID, thisObject);
                                }
                            }
                        }
                    }
                }
            }
        }   
    }

    /******************************************************************************
    * Submodule: Java_org_cplugin_CPluginControl_recieveResultsCallback           *
    * Import:    env (Pointer to JNIEnv), thisObject (jobject), x (jdouble),      *
    *            result (jdouble)												  *
    * Export:    None                                                             *
    * Assertion: Responsible for writing results from Event source to csv file.   *
    ******************************************************************************/
    JNIEXPORT void JNICALL Java_org_cplugin_CPluginControl_recieveResultsCallback(JNIEnv *env, jobject thisObject, jdouble x, jdouble result)
    {
        //Get the main class - using the instance from thisObject.
        jclass mainCls = env->GetObjectClass(thisObject);
        
        //Get the Double Class.
        jclass doubleObjectClass = env->FindClass("java/lang/Double");

        //Get the Double.toString(...) methodID.
        jmethodID doubleToStringMethodID = env->GetStaticMethodID(doubleObjectClass, "toString", "(D)Ljava/lang/String;");

        //Call the Double.toString(...) method and store the result in a jstring. 
        //Need to typecast to jstring or else compiler tells us that it has
        //encountered an invalid conversion from jobject to jstring.    
        jstring xJavaString = (jstring) env->CallStaticObjectMethod(doubleObjectClass, doubleToStringMethodID, x);

        //Call the Double.toString(...) method and store the result in a jstring. 
        //Need to typecast to jstring or else compiler tells us that it has
        //encountered an invalid conversion from jobject to jstring.       
        jstring resultJavaString = (jstring) env->CallStaticObjectMethod(doubleObjectClass, doubleToStringMethodID, result);

        //Convert the x jstring into a Native String.
        const char* xCString = env->GetStringUTFChars(xJavaString, NULL);

        //Convert the result jstring into a Native String.
        const char* resultCString = env->GetStringUTFChars(resultJavaString, NULL);

        //Need to get the fileName classfield.
        //Get the field ID for fileName.
        jfieldID fileNameFieldID = env->GetFieldID(mainCls, "fileName", "Ljava/lang/String;");
        
        //Get the object field from the filename FieldID.
        //Need to typecast to jstring or else compiler tells us that an invalid
        //conversion from jobject to jstring.
        jstring fileNameJavaString = (jstring) env->GetObjectField(thisObject, fileNameFieldID);
        
        //Convert the jstring into a Native C String.
        const char* fileNameCString = env->GetStringUTFChars(fileNameJavaString, NULL);

        //Create an output file stream object.
        ofstream cResultsFile;
        
        //Try catch for error handling.
        try
        {
            //Open the stream while specifying append mode.
            cResultsFile.open(fileNameCString, ios_base::app);
            
            cResultsFile.exceptions (ofstream::failbit | ofstream::badbit );

            if (!cResultsFile)
            {
                cout << "Couldn't open " << fileNameCString << "therefore ";
                cout << xCString << ", " << resultCString << "was not added to file.\n";
                //Need this to ensure that the buffer is flushed and stored output will
                //be displayed properly.
                fflush(stdout);
            }
            else
            {
                //Send x & result to the stream.
                cResultsFile << xCString << ", " << resultCString << "\n";

                //Close the file stream.
                cResultsFile.close();  
            }
        }
        catch (ofstream::failure ioFailure)
        {
            cerr << "Exception opening/reading/closing file\n";
        }


    }
} 