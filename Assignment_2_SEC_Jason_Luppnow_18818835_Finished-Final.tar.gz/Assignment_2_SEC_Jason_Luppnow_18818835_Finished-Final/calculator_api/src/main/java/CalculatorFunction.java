/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CalculatorFunction.java                                       *
* Purpose:          Represents the annotation CalculatorFunction which is used    *
*					to mark methods as callable functions for Jython.             *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     20/10/2020                                                    *
**********************************************************************************/

//Define the package for Calculator Function, this is the shared package for 
//anything pertaining to API functionality.
package org.calculator_api;

//Import Java Packages
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//@Retention specifies that the annotation is to be made available at runtime.
//@Target specifies where an annotation may appear - in our case we want
//our annotations to be restricted to methods only.
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface CalculatorFunction { }

//Any plugin that wants to add a new function to be evaluated needs to add this 
//annotation above their static function before the plugin is loaded.