/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ResultObserver.java                                           *
* Purpose:          Any Plugin can implement this interface and register itself   *
*                   with the api to receive a callback when an expression results *
*					are calculated.					           					  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Result Observer, this is the shared package for anything
//pertaining to API functionality.
package org.calculator_api;

public interface ResultObserver
{
	public void recieveResultsCallback(double x, double result);
}