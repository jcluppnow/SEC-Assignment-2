/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CalculatorEventSource.java                                    *
* Purpose:          Handles all event creation/notification. Plugins will		  *
*					register themselves with this class to recieve event          *
*					notifications.							   					  *
* Unit:             MAD                                                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Calculator Event Soruce, this is the shared package for 
//anything pertaining to API functionality.
package org.calculator_api;

//Import Java Packages
import java.util.ArrayList;

/**********************************************************************************
* Public Class:    CalculatorEventSource                                          *
* Extends:         None     			     	    		    			      *
* Implements:      None   							                              *
* Assertion:       Handles all event creation/notification. Plugins will		  *
*				   register themselves with this class to recieve event           *
*				   notifications.                                                 *
**********************************************************************************/
public class CalculatorEventSource
{
	/**********************************
	*           Classfields           *
	**********************************/
	private ArrayList<InputValuesObserver> inputValuesObservers;
	private ArrayList<ResultObserver> resultObservers;
	private ArrayList<ProgressObserver> progressObservers;
	
	/******************************************************************************
	* Submodule: CalculatorEventSource (Default Constructor)                      *
	* Import:    None 															  *
	* Export:    None                                                             *
	* Assertion: Initializes classfields.						    	          *
	******************************************************************************/
	public CalculatorEventSource()
	{
		//Create the classfields.
		inputValuesObservers = new ArrayList<InputValuesObserver>();
		resultObservers = new ArrayList<ResultObserver>();
		progressObservers = new ArrayList<ProgressObserver>();
	}
	
	/******************************************************************************
	*                                 ACCESSORS                                   *
	*******************************************************************************
	*        Responsible for accessing all CalculatorEventSource classfields.     *
	******************************************************************************/
	public void notifyInputValuesObservers(String equation, double min, double max, double increment)
	{

		//Iterate over every observer.
		for (InputValuesObserver currentObserver : inputValuesObservers)
		{
			//Call the specific notify method.
			currentObserver.recieveValuesCallBack(equation, min, max, increment);
		}
	}
	
	public void notifyResultObservers(double x, double result)
	{
		//Iterate over every observer.
		for (ResultObserver currentObserver : resultObservers)
		{
			//Call the specific notify method.
			currentObserver.recieveResultsCallback(x, result);
		}
	}
	
	public void notifyProgressObservers(double currentX)
	{
		//Iterate over every observer.
		for (ProgressObserver currentObserver : progressObservers)
		{
			//Call the specific notify method.
			currentObserver.notifyProgressCallback(currentX);
		}
	}
	
	/******************************************************************************
	*                                MUTATORS                                     *
	*******************************************************************************
	*        Responsible for setting all CalculatorEventSource classfields.       *
	******************************************************************************/
	//Any plugin wanting to recieve input values, will implement 
	//InputValuesObserver and within their start method call 
	//addInputValuesObserver().
	public void addInputValuesObserver(InputValuesObserver inObserver)
	{
		//Check if inObserver is valid.
		if (inObserver == null)
		{
			//Output an error message.
			System.out.println("Plugin is null.");
		}
		else
		{
			//Add the valid observer to it's designated list.
			inputValuesObservers.add(inObserver);
		}
	}
	
	//Any plugin wanting to recieve the result when it's calculated, will
	//need to implement ResultObserver and within their start method call
	//addResultObserver().
	public void addResultObserver(ResultObserver inObserver)
	{
		//Check if inObserver is valid.
		if (inObserver == null)
		{
			//Output an error message.
			System.out.println("Plugin is null.");
		}
		else
		{
			//Add the valid observer to it's designated list.
			resultObservers.add(inObserver);
		}
	}
	
	//Any plugin wanting to recieve current x progress, will need to 
	//implement ProgressObserver and within their start method call
	//addProgressObserver().
	public void addProgressObserver(ProgressObserver inObserver)
	{
		//Check if inObserver is valid.
		if (inObserver == null)
		{
			//Output an error message.
			System.out.println("Plugin is null.");
		}
		else
		{
			//Add the valid observer to it's designated list.
			progressObservers.add(inObserver);
		}
	}
}