/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         ProgressObserver.java                                         *
* Purpose:          Any Plugin can implement this interface and register itself   *
*                   to recieve updates when the x value of the expression         *
*					changes.				                					  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Progress Observer, this is the shared package for anything
//pertaining to API functionality.
package org.calculator_api;

public interface ProgressObserver
{
	public void notifyProgressCallback(double currentX);
}