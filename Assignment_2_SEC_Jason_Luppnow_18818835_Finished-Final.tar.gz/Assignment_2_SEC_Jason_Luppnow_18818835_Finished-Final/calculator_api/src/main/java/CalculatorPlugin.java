/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         CalculatorPlugin.java                                         *
* Purpose:          Interface that any Plugin must implement, without this the    *
*					program won't know how to start the programs running.		  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     14/10/2020                                                    *
**********************************************************************************/

//Define the package for Calculator Plugin, this is the shared package for anything
//pertaining to API functionality.
package org.calculator_api;

public interface CalculatorPlugin
{
	public void start(CalculatorEventSource api);
}