/**********************************************************************************
* Author:           Jason Luppnow                                                 *
* Filename:         InputValuesObserver.java                                      *
* Purpose:          Any Plugin can implement this interface and register itself   *
*					to recieve callbacks when input values are recieved.		  *
* Unit:             Software Engineering Concepts (SEC)                           *
* Date Created:     13/10/2020                                                    *
**********************************************************************************/

//Define the package for Input Values Observer, this is the shared package for 
//anything pertaining to API functionality.
package org.calculator_api;

public interface InputValuesObserver
{
	public void recieveValuesCallBack(String equation, double min, double max, double increment);
}